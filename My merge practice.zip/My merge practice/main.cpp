



#include <GL/gl.h>

#include<stdio.h>

#include<math.h>

#include <GL/glut.h>

#include<string.h>
#include <vector>
#include<windows.h>
using namespace std;

vector<pair<float,
float>> raindrops;
bool rainActive = false;

float  tx = 10, bx = 10, rx = 10, sx = 10, hx = 0;



bool isNight = false;


void circle(GLfloat rx, GLfloat ry, GLfloat cx, GLfloat cy)

{

    glBegin(GL_POLYGON);

    glVertex2f(cx, cy);

    for (int i = 0; i <= 360; i++)

    {

        float angle = i * 3.1416 / 180;

        float x = rx * cos(angle);

        float y = ry * sin(angle);

        glVertex2f((x + cx), (y + cy));

    }

    glEnd();

}

void round(GLfloat rx, GLfloat ry, GLfloat cx, GLfloat cy)

{

    glBegin(GL_POLYGON);

    glVertex2f(cx, cy);

    for (int i = 0; i <= 360; i++)

    {

        float angle = i * 3.1416 / 180;

        float x = rx * cos(angle);

        float y = ry * sin(angle);

        glVertex2f((x + cx), (y + cy));

    }

    glEnd();

}


float shift = 0; // a variable used to move the clouds right and left

void init(void)

{



    glMatrixMode(GL_PROJECTION);

    gluOrtho2D(0, 500, 0, 500);

}


// Green Bushes

void Bushes()

{

    // 1st Bushes

    glColor3ub(0, 128, 0);

    circle(20, 30, 20, 180);

    circle(20, 30, 40, 210);

    circle(20, 30, 60, 180);






}


// Front Road

void road()

{

    glColor3ub(0, 128, 0);

    glBegin(GL_POLYGON);

    glVertex2d(0, 0);

    glVertex2d(500, 0);

    glVertex2d(500, 75);

    glVertex2d(0, 75);

    glEnd();


    // car road

    glColor3ub(255, 240, 0);

    glBegin(GL_POLYGON);

    glVertex2d(0, 0);

    glVertex2d(500, 0);

    glVertex2d(500, 55);

    glVertex2d(0, 55);

    glEnd();


    glColor3ub(35, 35, 35);

    glBegin(GL_POLYGON);

    glVertex2d(0, 0);

    glVertex2d(500, 0);

    glVertex2d(500, 50);

    glVertex2d(0, 50);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(15, 20);

    glVertex2d(50, 20);

    glVertex2d(50, 30);

    glVertex2d(15, 30);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(65, 20);

    glVertex2d(100, 20);

    glVertex2d(100, 30);

    glVertex2d(65, 30);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(115, 20);

    glVertex2d(150, 20);

    glVertex2d(150, 30);

    glVertex2d(115, 30);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(165, 20);

    glVertex2d(200, 20);

    glVertex2d(200, 30);

    glVertex2d(165, 30);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(215, 20);

    glVertex2d(250, 20);

    glVertex2d(250, 30);

    glVertex2d(215, 30);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(265, 20);

    glVertex2d(300, 20);

    glVertex2d(300, 30);

    glVertex2d(265, 30);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(315, 20);

    glVertex2d(350, 20);

    glVertex2d(350, 30);

    glVertex2d(315, 30);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(365, 20);

    glVertex2d(400, 20);

    glVertex2d(400, 30);

    glVertex2d(365, 30);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(415, 20);

    glVertex2d(450, 20);

    glVertex2d(450, 30);

    glVertex2d(415, 30);

    glEnd();


    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2d(465, 20);

    glVertex2d(500, 20);

    glVertex2d(500, 30);

    glVertex2d(465, 30);

    glEnd();


}


void sun()

{



    static float shift = 0;

    glColor3ub(255, 195, 0);

    circle(20, 30, 450, 450+ shift);

    shift += 0.05; // Update shift to move the clouds

    if (shift > 180) {



        shift = -180; // Reset shift to prevent it from going out of bounds



    }

}


void moon()

{



    static float shift = 0;

    glColor3ub(255, 255, 204);

    circle(20, 30, 450, 450+ shift);

    shift += 0.05; // Update shift to move the clouds

    if (shift > 180) {



        shift = -180; // Reset shift to prevent it from going out of bounds



    }

}

  void drawHouse(float x, float y, int stories) {
    float buildingWidth = 100.0f;
    float storyHeight = 40.0f;

    // Draw building base (rectangle)
    glColor3f(0.6f, 0.4f, 0.2f); // Brown color
    glBegin(GL_POLYGON);
    glVertex2f(x, y);
    glVertex2f(x + buildingWidth, y);
    glVertex2f(x + buildingWidth, y + stories * storyHeight);
    glVertex2f(x, y + stories * storyHeight);
    glEnd();

    // Draw building roof (triangle)
    glColor3f(255, 0, 255); // Dark red color
    glBegin(GL_TRIANGLES);
    glVertex2f(x - 10.0f, y + stories * storyHeight);  // Left corner
    glVertex2f(x + buildingWidth + 10.0f, y + stories * storyHeight);  // Right corner
    glVertex2f(x + buildingWidth / 2.0f, y + stories * storyHeight + 40.0f);  // Top point
    glEnd();

    // Draw windows for each story
    for (int i = 0; i < stories; ++i) {
        float windowY = y + i * storyHeight + 10.0f;

        // Left window
        glColor3f(0.7f, 0.9f, 1.0f); // Light blue color
        glBegin(GL_POLYGON);
        glVertex2f(x + 15.0f, windowY);
        glVertex2f(x + 35.0f, windowY);
        glVertex2f(x + 35.0f, windowY + 20.0f);
        glVertex2f(x + 15.0f, windowY + 20.0f);
        glEnd();

        // Right window
        glBegin(GL_POLYGON);
        glVertex2f(x + 65.0f, windowY);
        glVertex2f(x + 85.0f, windowY);
        glVertex2f(x + 85.0f, windowY + 20.0f);
        glVertex2f(x + 65.0f, windowY + 20.0f);
        glEnd();
    }


}






void tree()

{

    // back tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(73, 75);

    glVertex2d(85, 75);

    glVertex2d(85, 350);

    glVertex2d(75, 350);

    glEnd();


    glColor3ub(0, 128, 0);


    circle(30, 40, 85, 370);

    circle(20, 30, 90, 340);

    circle(20, 30, 65, 395);


    // forward tree

    glColor3ub(0, 100, 0);

    circle(40, 50, 45, 360);

    glColor3ub(0, 100, 0);

    circle(30, 30, 60, 330);

    circle(20, 30, 30, 300);

    circle(20, 30, 60, 300);


    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(40, 72);

    glVertex2d(50, 74);

    glVertex2d(50, 296);

    glVertex2d(60, 320);

    glVertex2d(55, 326);

    glVertex2d(50, 300);

    glVertex2d(50, 350);

    glVertex2d(45, 355);

    glVertex2d(45, 310);

    glEnd();


glColor3ub(0, 100, 0);

    circle(40, 50, 235, 360);

    circle(30, 30, 210, 330);

    circle(20, 30, 230, 300);

    circle(20, 30, 260, 300);


glColor3ub(139, 69, 19);



glBegin(GL_POLYGON);



    glVertex2d(40 + 180, 75); // Adjusted x-coordinate for the right side



    glVertex2d(50 + 180, 74); // Adjusted x-coordinate for the right side



    glVertex2d(50 + 180, 296); // Adjusted x-coordinate for the right side



    glVertex2d(60 + 180, 320); // Adjusted x-coordinate for the right side



    glVertex2d(55 + 180, 326); // Adjusted x-coordinate for the right side



    glVertex2d(50 + 180, 300); // Adjusted x-coordinate for the right side



    glVertex2d(50 + 180, 350); // Adjusted x-coordinate for the right side



    glVertex2d(45 + 180, 350); // Adjusted x-coordinate for the right side



    glVertex2d(45 + 180, 350); // Adjusted x-coordinate for the right side



glEnd();


}

void little_tree()

{

    // 2nd tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(65, 60);

    glVertex2d(75, 60);

    glVertex2d(75, 100);

    glVertex2d(65, 100);

    glEnd();


    glColor3ub(0, 100, 0);

    circle(15, 20, 65, 110);

    circle(15, 20, 75, 110);

    circle(15, 20, 70, 130);


    // 1st tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(0, 60);

    glVertex2d(10, 60);

    glVertex2d(10, 100);

    glVertex2d(0, 100);

    glEnd();


    glColor3ub(0, 100, 0);

    circle(15, 20, 0, 110);

    circle(15, 20, 10, 110);

    circle(15, 20, 5, 130);


    // 3rd tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(125, 60);

    glVertex2d(135, 60);

    glVertex2d(135, 100);

    glVertex2d(125, 100);

    glEnd();


    glColor3ub(0, 100, 0);

    circle(15, 20, 125, 110);

    circle(15, 20, 135, 110);

    circle(15, 20, 130, 130);


    // 4th tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(190, 60);

    glVertex2d(200, 60);

    glVertex2d(200, 100);

    glVertex2d(190, 100);

    glEnd();

    glColor3ub(0, 100, 0);

    circle(15, 20, 190, 110);

    circle(15, 20, 200, 110);

    circle(15, 20, 195, 130);


    // tree 5

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(300, 60);

    glVertex2d(310, 60);

    glVertex2d(310, 100);

    glVertex2d(300, 100);

    glEnd();


    glColor3ub(0, 100, 0);

    circle(15, 20, 300, 110);

    circle(15, 20, 310, 110);

    circle(15, 20, 305, 130);



    // tree 7

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(425, 90);

    glVertex2d(430, 110);

    glVertex2d(435, 90);

    glVertex2d(425, 70);



    glEnd();



    glColor3ub(0, 100, 0);

    circle(15, 20, 425, 110);

    circle(15, 20, 435, 110);

    circle(15, 20, 430, 130);


    // tree 8

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(490, 60);

    glVertex2d(500, 60);

    glVertex2d(500, 100);

    glVertex2d(490, 100);

    glEnd();


    glColor3ub(0, 100, 0);

    circle(15, 20, 490, 110);

    circle(15, 20, 500, 110);

    circle(15, 20, 495, 130);



}



void little_tree2()

{

    // 2nd tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(65, 60);

    glVertex2d(75, 60);

    glVertex2d(75, 100);

    glVertex2d(65, 100);

    glEnd();


    glColor3ub(0, 152, 51);

    circle(15, 20, 65, 110);

    circle(15, 20, 75, 110);

    circle(15, 20, 70, 130);


    // 1st tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(0, 60);

    glVertex2d(10, 60);

    glVertex2d(10, 100);

    glVertex2d(0, 100);

    glEnd();


    glColor3ub(0, 152, 51);

    circle(15, 20, 0, 110);

    circle(15, 20, 10, 110);

    circle(15, 20, 5, 130);


    // 3rd tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(125, 60);

    glVertex2d(135, 60);

    glVertex2d(135, 100);

    glVertex2d(125, 100);

    glEnd();


    glColor3ub(0, 152, 51);

    circle(15, 20, 125, 110);

    circle(15, 20, 135, 110);

    circle(15, 20, 130, 130);


    // 4th tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(190, 60);

    glVertex2d(200, 60);

    glVertex2d(200, 100);

    glVertex2d(190, 100);

    glEnd();

    glColor3ub(0, 152, 51);

    circle(15, 20, 190, 110);

    circle(15, 20, 200, 110);

    circle(15, 20, 195, 130);


    // tree 5

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(300, 60);

    glVertex2d(310, 60);

    glVertex2d(310, 100);

    glVertex2d(300, 100);

    glEnd();


    glColor3ub(0, 152, 51);

    circle(15, 20, 300, 110);

    circle(15, 20, 310, 110);

    circle(15, 20, 305, 130);



    // tree 7

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(425, 90);

    glVertex2d(430, 110);

    glVertex2d(435, 90);

    glVertex2d(425, 70);



    glEnd();



    glColor3ub(0, 152, 51);

    circle(15, 20, 425, 110);

    circle(15, 20, 435, 110);

    circle(15, 20, 430, 130);


    // tree 8

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2d(490, 60);

    glVertex2d(500, 60);

    glVertex2d(500, 100);

    glVertex2d(490, 100);

    glEnd();


    glColor3ub(0, 152, 51);

    circle(15, 20, 490, 110);

    circle(15, 20, 500, 110);

    circle(15, 20, 495, 130);


}



void clouds() {



    static float shift = 0;


    glColor3ub(255, 255, 255);



    round(20, 30, 90 + shift, 460); // Cloud 1



    round(15, 20, 110 + shift, 460);



    round(15, 20, 70 + shift, 460);

    round(20, 30, 130 + shift, 430); // Cloud 2



    round(15, 20, 150 + shift, 430);



    round(15, 20, 110 + shift, 430);

    round(20, 30, 225 + shift, 400); // Cloud 3



    round(15, 20, 245 + shift, 400);



    round(15, 20, 205 + shift, 400);

    round(20, 30, 340 + shift, 380); // Cloud 4



    round(15, 20, 360 + shift, 380);



    round(15, 20, 320 + shift, 380);

    round(20, 30, 450 + shift, 390); // Cloud 5



    round(15, 20, 470 + shift, 390);



    round(15, 20, 430 + shift, 390);


    shift += 10; // Update shift to move the clouds

    if (shift > 400) {



        shift = -400; // Reset shift to prevent it from going out of bounds



    }

    glutPostRedisplay();



}


void clouds2() {



    static float shift = 0;


    glColor3ub(192, 192, 192);



    round(20, 30, 90 + shift, 460); // Cloud 1



    round(15, 20, 110 + shift, 460);



    round(15, 20, 70 + shift, 460);

    round(20, 30, 130 + shift, 430); // Cloud 2



    round(15, 20, 150 + shift, 430);



    round(15, 20, 110 + shift, 430);

    round(20, 30, 225 + shift, 400); // Cloud 3



    round(15, 20, 245 + shift, 400);



    round(15, 20, 205 + shift, 400);

    round(20, 30, 340 + shift, 380); // Cloud 4



    round(15, 20, 360 + shift, 380);



    round(15, 20, 320 + shift, 380);

    round(20, 30, 450 + shift, 390); // Cloud 5



    round(15, 20, 470 + shift, 390);



    round(15, 20, 430 + shift, 390);


    shift += 0.12; // Update shift to move the clouds

    if (shift > 400) {



        shift = -400; // Reset shift to prevent it from going out of bounds



    }

    glutPostRedisplay();



}



void car() {

    glPushMatrix();

    glTranslatef(tx, 0, 0);

    glColor3f(0.086, 0.024, 0.651);

    glBegin(GL_POLYGON);

    glVertex2d(410, 40);

    glVertex2d(490, 40);

    glVertex2d(485, 70);

    glVertex2d(410, 70);

    glEnd();


    glColor3f(0.086, 0.024, 0.651);

    glBegin(GL_POLYGON);

    glVertex2d(420, 70);

    glVertex2d(475, 70);

    glVertex2d(465, 100);

    glVertex2d(430, 100);

    glEnd();


    // car window

    glColor3ub(240, 250, 250);

    glBegin(GL_POLYGON);

    glVertex2d(425, 70);

    glVertex2d(445, 70);

    glVertex2d(445, 90);

    glVertex2d(430, 90);

    glEnd();


    // car window

    glColor3ub(240, 250, 250);

    glBegin(GL_POLYGON);

    glVertex2d(450, 70);

    glVertex2d(470, 70);

    glVertex2d(465, 90);

    glVertex2d(450, 90);

    glEnd();


    // car wheel

    glColor3ub(0, 0, 0);

    circle(10, 14, 435, 40);

    circle(10, 14, 465, 40);


    glColor3ub(245, 245, 245);

    circle(6, 10, 435, 40);

    circle(6, 10, 465, 40);


    glPopMatrix();

    tx += .4;

    if (tx > 0)

        tx = -500;

    glutPostRedisplay();

}


void truck() {

    glPushMatrix();

    glTranslatef(bx, 0, 0);

    glColor3f(0.612, 0.604, 0.573);

    glBegin(GL_POLYGON);

    glVertex2d(450, 40);

    glVertex2d(505, 40);

    glVertex2d(505, 110);

    glVertex2d(450, 110);

    glEnd();


    glColor3f(0.796, 0.831, 0.027);

    glBegin(GL_POLYGON);

    glVertex2d(505, 40);

    glVertex2d(535, 40);

    glVertex2d(535, 70);

    glVertex2d(505, 70);


    glBegin(GL_POLYGON);

    glVertex2d(505, 70);

    glVertex2d(525, 70);

    glVertex2d(515, 90);

    glVertex2d(505, 90);

    glEnd();

    // window

    glColor3ub(240, 250, 250);

    glBegin(GL_POLYGON);

    glVertex2d(505, 70);

    glVertex2d(520, 70);

    glVertex2d(515, 85);

    glVertex2d(505, 85);

    glEnd();

    // wheels

    glColor3ub(0, 0, 0);

    circle(10, 14, 460, 40);

    circle(10, 14, 510, 40);


    glColor3ub(245, 245, 245);

    circle(6, 10, 460, 40);

    circle(6, 10, 510, 40);


    glPopMatrix();

    bx += .3;

    if (bx > 0)

        bx = -510;

    glutPostRedisplay();

}


void flower() {

    glColor3ub(255, 0, 0);

    circle(3, 5, 450, 210);

    circle(3, 5, 455, 205);

    circle(3, 5, 455, 215);

    circle(3, 5, 460, 210);

    glColor3ub(255, 215, 0);

    circle(3, 5, 455, 210);


    glColor3ub(255, 0, 0);

    circle(3, 5, 440, 195);

    circle(3, 5, 440, 185);

    circle(3, 5, 435, 190);

    circle(3, 5, 445, 190);

    glColor3ub(255, 215, 0);

    circle(3, 5, 440, 190);


    glColor3ub(255, 0, 0);

    circle(3, 5, 470, 195);

    circle(3, 5, 470, 185);

    circle(3, 5, 465, 190);

    circle(3, 5, 475, 190);

    glColor3ub(255, 215, 0);

    circle(3, 5, 470, 190);


    // left side flower


    glColor3ub(255, 0, 0);

    circle(3, 5, 30, 205);

    circle(3, 5, 30, 195);

    circle(3, 5, 25, 200);

    circle(3, 5, 35, 200);

    glColor3ub(255, 215, 0);

    circle(3, 5, 30, 200);


    glColor3ub(255, 215, 0);

    circle(3, 5, 10, 215);

    circle(3, 5, 10, 205);

    circle(3, 5, 5, 210);

    circle(3, 5, 15, 210);

    glColor3ub(255, 0, 0);



    circle(3, 5, 10, 210);


}


void roadLight()

{

    glColor3ub(0, 0, 0);

    glBegin(GL_POLYGON);

    glVertex2d(80, 50);

    glVertex2d(85, 50);

    glVertex2d(85, 180);

    glVertex2d(80, 180);

    glEnd();


    glColor3ub(255, 255, 255);

    circle(10, 15, 83, 180);


     glColor3ub(0, 0, 0);



    glBegin(GL_POLYGON);



    glVertex2d(250, 50);



    glVertex2d(255, 50);



    glVertex2d(255, 180);



    glVertex2d(250, 180);



    glEnd();


    glColor3ub(255, 255, 255);



    circle(10, 15, 253, 180);


     glColor3ub(1, 1, 1);



    glBegin(GL_POLYGON);



    glVertex2d(420, 50);



    glVertex2d(425, 50);



    glVertex2d(425, 180);



    glVertex2d(420, 180);



    glEnd();




     glColor3ub(111, 344, 1);



    glBegin(GL_POLYGON);



    glVertex2d(448, 73);



    glVertex2d(462, 73);



    glVertex2d(458, 146);



    glVertex2d(448, 181);



    glEnd();


  glColor3ub(111, 344, 1);



    glBegin(GL_POLYGON);



    glVertex2d(448, 73);



    glVertex2d(462, 73);



    glVertex2d(458, 146);



    glVertex2d(448, 181);



    glEnd();


    glColor3ub(255, 255, 255);



    circle(10, 15, 423, 180);

}




void roadLight1()

{

    glColor3ub(0, 0, 0);

    glBegin(GL_POLYGON);

    glVertex2d(80, 50);

    glVertex2d(85, 50);

    glVertex2d(85, 180);

    glVertex2d(80, 180);

    glEnd();


    glColor3ub(255, 255, 0);

    circle(10, 15, 83, 180);


     glColor3ub(0, 0, 0);



    glBegin(GL_POLYGON);



    glVertex2d(250, 50);



    glVertex2d(255, 50);



    glVertex2d(255, 180);



    glVertex2d(250, 180);



    glEnd();


    glColor3ub(255, 255, 0);



    circle(10, 15, 253, 180);


     glColor3ub(1, 1, 1);



    glBegin(GL_POLYGON);



    glVertex2d(420, 50);



    glVertex2d(425, 50);



    glVertex2d(425, 180);



    glVertex2d(420, 180);



    glEnd();




     glColor3ub(111, 344, 1);



    glBegin(GL_POLYGON);



    glVertex2d(448, 73);



    glVertex2d(462, 73);



    glVertex2d(458, 146);



    glVertex2d(448, 181);



    glEnd();


  glColor3ub(111, 344, 1);



    glBegin(GL_POLYGON);



    glVertex2d(448, 73);



    glVertex2d(462, 73);



    glVertex2d(458, 146);



    glVertex2d(448, 181);



    glEnd();


    glColor3ub(255, 255, 0);



    circle(10, 15, 423, 180);

}
 void drawRain() {
    if (rainActive) {
        glColor3f(0.0f, 0.0f, 1.0f); // Blue color for rain
        glBegin(GL_LINES); // Drawing lines for raindrops
        for (auto &raindrop : raindrops) {
            glVertex2f(raindrop.first, raindrop.second);
            glVertex2f(raindrop.first, raindrop.second - 10); // Draw as lines
            raindrop.second -= 5; // Move raindrop downwards

            if (raindrop.second < 0) { // Reset raindrop if it falls below screen
                raindrop.second = 500;
                raindrop.first = rand() % 500; // Randomize X position
            }
        }
        glEnd();
    }
}
void handleMouseClick(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        rainActive = true; // Start rain
        if (raindrops.empty()) {
            // Initialize raindrops only once
            for (int i = 0; i < 200; ++i) {
                raindrops.push_back({rand() % 500, rand() % 500});
            }
        }
    } else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
        rainActive = false; // Stop rain
    }
}
  void display(void) {
    glClear(GL_COLOR_BUFFER_BIT);
    // Sky Color
    if (isNight) {
        glColor3ub(64, 64, 64); // Night sky color
    } else {
        glColor3ub(30, 144, 255); // Day sky color
    }
    glBegin(GL_POLYGON);
    glVertex2d(0, 0);
    glVertex2d(500, 0);
    glVertex2d(500, 500);
    glVertex2d(0, 500);
    glEnd();
    // Bushes
    Bushes();
    // Ground Color
    glColor3f(0.141, 0.602, 0.153);
    glBegin(GL_POLYGON);
    glVertex2d(0, 0);
    glVertex2d(500, 0);
    glVertex2d(500, 180);
    glVertex2d(0, 180);
    glEnd();
    // Draw buildings
    drawHouse(100.0f, 100.0f, 5); // Building 1
    drawHouse(250.0f, 100.0f, 4); // Building 2
    drawHouse(400.0f, 100.0f, 3); // Building 3
    // Other elements (trees, road, sun/moon, clouds, etc.)
    if (isNight) {
        little_tree2();
        moon();
        clouds2();
        roadLight1();
    } else {
        little_tree();
        sun();
        clouds();
        roadLight();
    }
    road();
    tree();
    truck();
    car();
    flower();
    drawRain(); // Add this line to draw rain
    glFlush();
    glutSwapBuffers();
}
 void handleKeypress(unsigned char key, int x, int y) {
    switch (tolower(key)) {
        case 'd':
            glutDisplayFunc(display);
            isNight = false;
            glutPostRedisplay();
            break;
        case 'n':
            glutDisplayFunc(display);
            isNight = true;
            glutPostRedisplay();
            break;
    }
}



 int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(900, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("road side view");
    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(handleKeypress);
    glutMouseFunc(handleMouseClick); // Register mouse callback
    glutMainLoop();
    return 0;
}

