<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Output Tables</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>Array to Declare</th>
        </tr>
        <?php foreach ($total_array as $num): ?>
            <tr>
                <?php foreach ($num as $value): ?>
                    <td><?php echo $value; ?></td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
    </table>

    <table>
        <tr>
            <th>Numbers</th>
        </tr>
        <?php for ($i = 3; $i >= 1; $i--): ?>
            <tr>
                <td>
                    <?php for ($j = 1; $j <= $i; $j++): ?>
                        <?php echo $j . " "; ?>
                    <?php endfor; ?>
                </td>
            </tr>
        <?php endfor; ?>
    </table>

    <table>
        <tr>
            <th>Letters</th>
        </tr>
        <?php $word = 'A'; ?>
        <?php for ($i = 0; $i < 3; $i++): ?>
            <tr>
                <td>
                    <?php for ($j = 0; $j <= $i; $j++): ?>
                        <?php echo $word++ . " "; ?>
                    <?php endfor; ?>
                </td>
            </tr>
        <?php endfor; ?>
    </table>
</body>
</html>
