-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2024 at 06:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dmrs`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `event_place` varchar(255) NOT NULL,
  `event_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_date`, `event_time`, `event_place`, `event_type`) VALUES
(1, 'Joy Bangla Music Fest 2024', '2024-03-26', '18:00:00', 'Army Stadium', 'Music'),
(2, 'Music Fest Concert 2024', '2024-03-31', '20:00:00', 'ICCB EXPO ZONE', 'Music'),
(3, 'Business Conference on Building Smart Bangladesh', '2024-04-10', '11:00:00', 'Bangabandhu International Conference Center', 'Business'),
(4, 'Textile Sourcing Meet', '2024-04-01', '12:00:00', 'International Convention City Bashundhara (ICCB)\r\n', 'Business'),
(5, 'Tech Expo Bangladesh 2024', '2024-05-15', '15:30:00', 'International Convention City Bashundhara (ICCB)', 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `ticketsells`
--

CREATE TABLE `ticketsells` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `ticket_type` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `discount_coupon` varchar(255) DEFAULT NULL,
  `username` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticketsells`
--

INSERT INTO `ticketsells` (`id`, `customer_name`, `event_name`, `ticket_type`, `quantity`, `discount_coupon`, `username`) VALUES
(1, 'H. R. Masum', 'Tech Expo Bangladesh 2024', 'General Pass', 1, '', 'hrm99'),
(2, 'Masum', 'Business Conference on Building Smart Bangladesh', 'General Pass', 1, '', 'hrm67'),
(9, 'H R M', 'Joy Bangla Music Fest 2024', 'VIP Pass', 2, '', NULL),
(10, 'Masum', 'Music Fest Concert 2024', 'General Pass', 3, 'DMRS50', NULL),
(11, 'H. R. Masum', 'Music Fest Concert 2024', 'VIP Pass', 2, '', 'hrm99'),
(14, 'Masum', 'Textile Sourcing Meet', 'General Pass', 1, '', 'hrm67'),
(15, 'H. R. Masum', 'Music Fest Concert 2024', 'General Pass', 1, '', 'hrm99'),
(16, 'H. R. Masum', 'Tech Expo Bangladesh 2024', 'VIP Pass', 1, '', 'hrm99');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uID` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) DEFAULT NULL,
  `phone` varchar(16) NOT NULL,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(24) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` varchar(32) NOT NULL,
  `usertype` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uID`, `name`, `email`, `phone`, `username`, `password`, `gender`, `dob`, `usertype`) VALUES
(1, 'Masum', 'hrmasum67@gmail.com', '01794669675', 'hrm67', 'hrm67', 'Male', '1999-10-28', 'Customer'),
(2, 'H. R. Masum', 'hrmasum99.study@gmail.com', '01990618077', 'hrm99', '1234', 'Male', '1999-10-28', 'Customer'),
(3, 'Masum', 'hrmasum99.student@gmail.com', '01990618077', 'linux99', 'linux99', 'Male', '1999-10-28', 'Customer'),
(4, 'H R M', 'hrmasum85@gmail.com', '01567965315', 'hrm85', 'hrm85', 'Male', '1999-10-28', 'Customer'),
(5, 'Mahmudur Rahman Masum', 'hrmasum84@gmail.com', '01794669675', 'hrm84', '12345', 'Male', '1999-10-28', 'Host'),
(6, 'XYZ', 'xyz@gamil.com', '01756365364', 'xyz', '1234', 'Female', '2000-01-01', 'Host');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticketsells`
--
ALTER TABLE `ticketsells`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uID`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ticketsells`
--
ALTER TABLE `ticketsells`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
