<?php
print ("hello Kaga");
$name = "Mustakim";
print($name);
$age = 21;
print($age);